IF DB_ID('DynamicRuleEngineDb') IS NULL
BEGIN
    CREATE DATABASE DynamicRuleEngineDb;
END
GO

USE DynamicRuleEngineDb;
GO

IF OBJECT_ID('WorkflowJson', 'U') IS NOT NULL DROP TABLE WorkflowJson;
IF OBJECT_ID('ScoreDefinitions', 'U') IS NOT NULL DROP TABLE ScoreDefinitions;
IF OBJECT_ID('Rules', 'U') IS NOT NULL DROP TABLE Rules;
IF OBJECT_ID('FrameworkParameters', 'U') IS NOT NULL DROP TABLE FrameworkParameters;
IF OBJECT_ID('Workflows', 'U') IS NOT NULL DROP TABLE Workflows;
GO

CREATE TABLE Workflows
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    WorkflowCode NVARCHAR(100) NOT NULL UNIQUE,
    WorkflowName NVARCHAR(200) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1
);

CREATE TABLE FrameworkParameters
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    WorkflowId INT NOT NULL,
    ParameterCode NVARCHAR(100) NOT NULL,
    DisplayName NVARCHAR(200) NOT NULL,
    Weight DECIMAL(10,2) NOT NULL,
    WhyItMatters NVARCHAR(1000) NULL,
    HowToMeasure NVARCHAR(1000) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    SortOrder INT NOT NULL,
    CONSTRAINT FK_FrameworkParameters_Workflows FOREIGN KEY (WorkflowId) REFERENCES Workflows(Id)
);

CREATE TABLE ScoreDefinitions
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    ParameterDefinitionId INT NOT NULL,
    Score INT NOT NULL,
    Description NVARCHAR(500) NOT NULL,
    CONSTRAINT FK_ScoreDefinitions_Parameters FOREIGN KEY (ParameterDefinitionId) REFERENCES FrameworkParameters(Id)
);

CREATE TABLE Rules
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    WorkflowId INT NOT NULL,
    RuleName NVARCHAR(200) NOT NULL,
    RuleExpression NVARCHAR(MAX) NOT NULL,
    RuleType NVARCHAR(50) NOT NULL DEFAULT 'Validation',
    ErrorMessage NVARCHAR(1000) NULL,
    Enabled BIT NOT NULL DEFAULT 1,
    SortOrder INT NOT NULL,
    CONSTRAINT FK_Rules_Workflows FOREIGN KEY (WorkflowId) REFERENCES Workflows(Id)
);

CREATE TABLE WorkflowJson
(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    WorkflowId INT NOT NULL UNIQUE,
    Version INT NOT NULL,
    JsonContent NVARCHAR(MAX) NOT NULL,
    GeneratedAtUtc DATETIME2 NOT NULL,
    CONSTRAINT FK_WorkflowJson_Workflows FOREIGN KEY (WorkflowId) REFERENCES Workflows(Id)
);
GO

INSERT INTO Workflows (WorkflowCode, WorkflowName) VALUES
('BusinessFramework', 'Business Framework'),
('OperationalFramework', 'Operational Framework'),
('FinancialFramework', 'Financial Framework');

INSERT INTO FrameworkParameters (WorkflowId, ParameterCode, DisplayName, Weight, WhyItMatters, HowToMeasure, IsActive, SortOrder)
SELECT Id, 'PPA', 'PPA Availability', 40, 'Measures the availability of contracted power purchase arrangements.', 'Review contracted PPA availability and supporting agreements.', 1, 1 FROM Workflows WHERE WorkflowCode='BusinessFramework'
UNION ALL SELECT Id, 'DIVERSIFICATION', 'Asset Diversification', 30, 'Shows how diversified the underlying asset base is.', 'Review asset concentration and portfolio mix.', 1, 2 FROM Workflows WHERE WorkflowCode='BusinessFramework'
UNION ALL SELECT Id, 'PPA_MIX', 'PPA Mix', 30, 'Shows the quality and balance of the PPA mix.', 'Review the mix of contracted and merchant exposure.', 1, 3 FROM Workflows WHERE WorkflowCode='BusinessFramework'
UNION ALL SELECT Id, 'AVAILABILITY', 'Plant Availability', 40, 'Indicates operating availability of the plant.', 'Use plant availability records for the assessment period.', 1, 1 FROM Workflows WHERE WorkflowCode='OperationalFramework'
UNION ALL SELECT Id, 'GRID', 'Grid Availability', 30, 'Indicates the reliability of grid connectivity.', 'Review grid outage and availability records.', 1, 2 FROM Workflows WHERE WorkflowCode='OperationalFramework'
UNION ALL SELECT Id, 'PLF', 'Plant Load Factor', 30, 'Indicates how effectively the plant capacity is used.', 'Review PLF for the assessment period.', 1, 3 FROM Workflows WHERE WorkflowCode='OperationalFramework'
UNION ALL SELECT Id, 'DSCR', 'DSCR', 40, 'Measures debt service coverage.', 'Use the approved financial model and debt service data.', 1, 1 FROM Workflows WHERE WorkflowCode='FinancialFramework'
UNION ALL SELECT Id, 'IRR', 'IRR', 30, 'Measures the internal rate of return used in the assessment.', 'Use the approved investment model.', 1, 2 FROM Workflows WHERE WorkflowCode='FinancialFramework'
UNION ALL SELECT Id, 'LEVERAGE', 'Leverage', 30, 'Shows the level of financial leverage.', 'Review debt to capital or the approved leverage metric.', 1, 3 FROM Workflows WHERE WorkflowCode='FinancialFramework';

INSERT INTO ScoreDefinitions (ParameterDefinitionId, Score, Description)
SELECT p.Id, s.Score, CASE s.Score WHEN 1 THEN 'Very Low' WHEN 2 THEN 'Low' WHEN 3 THEN 'Moderate' WHEN 4 THEN 'High' ELSE 'Very High' END
FROM FrameworkParameters p
CROSS JOIN (VALUES (1),(2),(3),(4),(5)) s(Score);

INSERT INTO Rules (WorkflowId, RuleName, RuleExpression, RuleType, ErrorMessage, Enabled, SortOrder)
SELECT Id, 'ValidatePPA', 'input1.PPA >= 1 && input1.PPA <= 5', 'Validation', 'PPA score must be between 1 and 5.', 1, 1 FROM Workflows WHERE WorkflowCode='BusinessFramework'
UNION ALL SELECT Id, 'ValidateDiversification', 'input1.DIVERSIFICATION >= 1 && input1.DIVERSIFICATION <= 5', 'Validation', 'Diversification score must be between 1 and 5.', 1, 2 FROM Workflows WHERE WorkflowCode='BusinessFramework'
UNION ALL SELECT Id, 'ValidatePPAMix', 'input1.PPA_MIX >= 1 && input1.PPA_MIX <= 5', 'Validation', 'PPA Mix score must be between 1 and 5.', 1, 3 FROM Workflows WHERE WorkflowCode='BusinessFramework'
UNION ALL SELECT Id, 'CalculateWeightedScore', '(input1.PPA * 40 + input1.DIVERSIFICATION * 30 + input1.PPA_MIX * 30) / 100m', 'Calculation', NULL, 1, 4 FROM Workflows WHERE WorkflowCode='BusinessFramework'
UNION ALL SELECT Id, 'ValidateAvailability', 'input1.AVAILABILITY >= 1 && input1.AVAILABILITY <= 5', 'Validation', 'Plant Availability score must be between 1 and 5.', 1, 1 FROM Workflows WHERE WorkflowCode='OperationalFramework'
UNION ALL SELECT Id, 'ValidateGrid', 'input1.GRID >= 1 && input1.GRID <= 5', 'Validation', 'Grid Availability score must be between 1 and 5.', 1, 2 FROM Workflows WHERE WorkflowCode='OperationalFramework'
UNION ALL SELECT Id, 'ValidatePLF', 'input1.PLF >= 1 && input1.PLF <= 5', 'Validation', 'PLF score must be between 1 and 5.', 1, 3 FROM Workflows WHERE WorkflowCode='OperationalFramework'
UNION ALL SELECT Id, 'CalculateWeightedScore', '(input1.AVAILABILITY * 40 + input1.GRID * 30 + input1.PLF * 30) / 100m', 'Calculation', NULL, 1, 4 FROM Workflows WHERE WorkflowCode='OperationalFramework'
UNION ALL SELECT Id, 'ValidateDSCR', 'input1.DSCR >= 1 && input1.DSCR <= 5', 'Validation', 'DSCR score must be between 1 and 5.', 1, 1 FROM Workflows WHERE WorkflowCode='FinancialFramework'
UNION ALL SELECT Id, 'ValidateIRR', 'input1.IRR >= 1 && input1.IRR <= 5', 'Validation', 'IRR score must be between 1 and 5.', 1, 2 FROM Workflows WHERE WorkflowCode='FinancialFramework'
UNION ALL SELECT Id, 'ValidateLeverage', 'input1.LEVERAGE >= 1 && input1.LEVERAGE <= 5', 'Validation', 'Leverage score must be between 1 and 5.', 1, 3 FROM Workflows WHERE WorkflowCode='FinancialFramework'
UNION ALL SELECT Id, 'CalculateWeightedScore', '(input1.DSCR * 40 + input1.IRR * 30 + input1.LEVERAGE * 30) / 100m', 'Calculation', NULL, 1, 4 FROM Workflows WHERE WorkflowCode='FinancialFramework';

-- Start with version 1 so the application can evaluate immediately after running this script.
DECLARE @GeneratedAt DATETIME2 = SYSUTCDATETIME();

INSERT INTO WorkflowJson (WorkflowId, Version, JsonContent, GeneratedAtUtc)
SELECT w.Id, 1,
CASE w.WorkflowCode
WHEN 'BusinessFramework' THEN N'[{"workflowName":"BusinessFramework","ruleExpressionType":"LambdaExpression","rules":[{"ruleName":"ValidatePPA","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"input1.PPA >= 1 && input1.PPA <= 5","errorMessage":"PPA score must be between 1 and 5."},{"ruleName":"ValidateDiversification","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"input1.DIVERSIFICATION >= 1 && input1.DIVERSIFICATION <= 5","errorMessage":"Diversification score must be between 1 and 5."},{"ruleName":"ValidatePPAMix","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"input1.PPA_MIX >= 1 && input1.PPA_MIX <= 5","errorMessage":"PPA Mix score must be between 1 and 5."},{"ruleName":"CalculateWeightedScore","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"true","errorMessage":null,"actions":{"onSuccess":{"name":"OutputExpression","context":{"expression":"(input1.PPA * 40 + input1.DIVERSIFICATION * 30 + input1.PPA_MIX * 30) / 100m"}}}}]}]'
WHEN 'OperationalFramework' THEN N'[{"workflowName":"OperationalFramework","ruleExpressionType":"LambdaExpression","rules":[{"ruleName":"ValidateAvailability","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"input1.AVAILABILITY >= 1 && input1.AVAILABILITY <= 5","errorMessage":"Plant Availability score must be between 1 and 5."},{"ruleName":"ValidateGrid","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"input1.GRID >= 1 && input1.GRID <= 5","errorMessage":"Grid Availability score must be between 1 and 5."},{"ruleName":"ValidatePLF","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"input1.PLF >= 1 && input1.PLF <= 5","errorMessage":"PLF score must be between 1 and 5."},{"ruleName":"CalculateWeightedScore","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"true","errorMessage":null,"actions":{"onSuccess":{"name":"OutputExpression","context":{"expression":"(input1.AVAILABILITY * 40 + input1.GRID * 30 + input1.PLF * 30) / 100m"}}}}]}]'
WHEN 'FinancialFramework' THEN N'[{"workflowName":"FinancialFramework","ruleExpressionType":"LambdaExpression","rules":[{"ruleName":"ValidateDSCR","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"input1.DSCR >= 1 && input1.DSCR <= 5","errorMessage":"DSCR score must be between 1 and 5."},{"ruleName":"ValidateIRR","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"input1.IRR >= 1 && input1.IRR <= 5","errorMessage":"IRR score must be between 1 and 5."},{"ruleName":"ValidateLeverage","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"input1.LEVERAGE >= 1 && input1.LEVERAGE <= 5","errorMessage":"Leverage score must be between 1 and 5."},{"ruleName":"CalculateWeightedScore","enabled":true,"ruleExpressionType":"LambdaExpression","expression":"true","errorMessage":null,"actions":{"onSuccess":{"name":"OutputExpression","context":{"expression":"(input1.DSCR * 40 + input1.IRR * 30 + input1.LEVERAGE * 30) / 100m"}}}}]}]'
END,
@GeneratedAt
FROM Workflows w;
GO
