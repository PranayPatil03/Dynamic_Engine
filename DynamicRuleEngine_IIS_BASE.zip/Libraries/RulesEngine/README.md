# Microsoft RulesEngine source

This folder contains the RulesEngine source extracted from the Microsoft RulesEngine repository supplied for this project. The application references `RulesEngine.csproj` directly from Infrastructure.
