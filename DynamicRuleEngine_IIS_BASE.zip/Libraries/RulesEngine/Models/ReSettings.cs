﻿// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using RulesEngine.Actions;
using RulesEngine.HelperFunctions;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace RulesEngine.Models
{
    [ExcludeFromCodeCoverage]
    public class ReSettings
    {
        public ReSettings() { }

        // create a copy of settings
        internal ReSettings(ReSettings reSettings)
        {
            CustomTypes = reSettings.CustomTypes;
            CustomActions = reSettings.CustomActions;
            EnableExceptionAsErrorMessage = reSettings.EnableExceptionAsErrorMessage;
            IgnoreException = reSettings.IgnoreException;
            EnableFormattedErrorMessage = reSettings.EnableFormattedErrorMessage;
            EnableScopedParams = reSettings.EnableScopedParams;
            NestedRuleExecutionMode = reSettings.NestedRuleExecutionMode;
            CacheConfig = reSettings.CacheConfig;
            IsExpressionCaseSensitive = reSettings.IsExpressionCaseSensitive;
            AutoRegisterInputType = reSettings.AutoRegisterInputType;
            EnableAssemblyScanning = reSettings.EnableAssemblyScanning;
            UseFastExpressionCompiler = reSettings.UseFastExpressionCompiler;
            EnableExceptionAsErrorMessageForRuleExpressionParsing = reSettings.EnableExceptionAsErrorMessageForRuleExpressionParsing;
            AutoExecuteActions = reSettings.AutoExecuteActions;
            EnableParallelRuleCompilation = reSettings.EnableParallelRuleCompilation;
        }


        /// <summary>
        /// Get/Set the custom types to be used in Rule expressions
        /// </summary>
        public Type[] CustomTypes { get; set; }

        /// <summary>
        /// Get/Set the custom actions that can be used in the Rules
        /// </summary>
        public Dictionary<string, Func<ActionBase>> CustomActions { get; set; }

        /// <summary>
        /// When set to true, returns any exception occurred 
        /// while rule execution as ErrorMessage 
        /// otherwise throws an exception
        /// </summary>
        /// <remarks>This setting is only applicable if IgnoreException is set to false</remarks>
        public bool EnableExceptionAsErrorMessage { get; set; } = true;

        /// <summary>
        /// When set to true, it will ignore any exception thrown with rule compilation/execution
        /// </summary>
        public bool IgnoreException { get; set; } = false;

        /// <summary>
        /// Enables ErrorMessage Formatting 
        /// </summary>
        public bool EnableFormattedErrorMessage { get; set; } = true;

        /// <summary>
        /// Enables Global params and local params for rules
        /// </summary>
        public bool EnableScopedParams { get; set; } = true;

        /// <summary>
        /// Sets whether expression are case sensitive
        /// </summary>
        public bool IsExpressionCaseSensitive { get; set; } = false;

        /// <summary>
        /// Auto Registers input type in Custom Type to allow calling method on type.
        /// Default : true
        /// </summary>
        public bool AutoRegisterInputType { get; set; } = true;

        /// <summary>
        /// When true (default), the CustomTypeProvider scans all assemblies loaded in the
        /// AppDomain for types decorated with [DynamicLinqType] so they can be used in rule
        /// expressions. Set to false to opt out of this scan entirely (only the explicitly
        /// supplied CustomTypes and input types are registered), which avoids the scanning
        /// cost on workflow registration. See #749.
        /// </summary>
        public bool EnableAssemblyScanning { get; set; } = true;

        /// <summary>
        /// Sets the mode for Nested rule execution, Default: All
        /// </summary>
        public NestedRuleExecutionMode NestedRuleExecutionMode { get; set; } = NestedRuleExecutionMode.All;
        public MemCacheConfig CacheConfig { get; set; }
        /// <summary>
        /// Whether to use FastExpressionCompiler for rule compilation
        /// </summary>
        public bool UseFastExpressionCompiler { get; set; } = false;
        /// <summary>
        /// Sets the mode for ParsingException to cascade to child elements and result in a expression parser
        /// Default: true
        /// </summary>
        public bool EnableExceptionAsErrorMessageForRuleExpressionParsing { get; set; } = true;

        /// <summary>
        /// When true (default), ExecuteAllRulesAsync automatically runs each matched rule's
        /// OnSuccess/OnFailure action after evaluation. Set to false to evaluate rules only and
        /// run actions yourself (e.g. via ExecuteActionWorkflowAsync) for selective control. See #596.
        /// </summary>
        public bool AutoExecuteActions { get; set; } = true;

        /// <summary>
        /// When true, rules within a workflow are compiled in parallel during registration.
        /// Significantly reduces warmup time for workflows with many thousands of rules.
        /// </summary>
        /// <remarks>
        /// Silently falls back to serial compilation when:
        /// <list type="bullet">
        /// <item><see cref="UseFastExpressionCompiler"/> is also <c>true</c> — FastExpressionCompiler
        /// regresses ~3× under parallel contention, so the engine declines to parallelize that mix.</item>
        /// <item>The workflow has fewer enabled rules than an internal threshold (32) where
        /// the dispatch cost outweighs the speedup.</item>
        /// </list>
        /// Default: <c>false</c>.
        /// </remarks>
        public bool EnableParallelRuleCompilation { get; set; } = false;
    }

    public enum NestedRuleExecutionMode
    {
        /// <summary>
        /// Executes all nested rules
        /// </summary>
        All,
        /// <summary>
        /// Skips nested rules whose execution does not impact parent rule's result
        /// </summary>
        Performance
    }
}
