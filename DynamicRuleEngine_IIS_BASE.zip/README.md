# DynamicRuleEngine

IIS-based .NET 10 solution with:

- Domain / Application / Infrastructure / API / Web projects
- Microsoft RulesEngine source under Libraries/RulesEngine
- EF Core + SQL Server
- Repository + Service pattern
- MudBlazor Web UI
- Business, Operational and Financial framework pages
- Parameter and Rule configuration pages
- Persisted Workflow JSON and versioning
- No stored procedures

## Hosting

Both API and Web are configured for IIS. See `README_IIS.md`.
