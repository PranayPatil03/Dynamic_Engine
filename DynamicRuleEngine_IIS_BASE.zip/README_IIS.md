# DynamicRuleEngine - IIS Base Setup

This solution is configured as an IIS-hosted ASP.NET Core application.
It does not require IIS Express for the Web or API.

## Applications

Create two IIS applications under Default Web Site:

- DynamicRuleEngineApi -> C:\inetpub\wwwroot\DynamicRuleEngineApi
- DynamicRuleEngineWeb -> C:\inetpub\wwwroot\DynamicRuleEngineWeb

Recommended URLs:

- http://localhost/DynamicRuleEngineApi
- http://localhost/DynamicRuleEngineWeb

## Application Pool

Use an application pool for each application with:

- .NET CLR Version: No Managed Code
- Managed pipeline: Integrated
- Identity: ApplicationPoolIdentity

Install the ASP.NET Core Hosting Bundle for the installed .NET 10 runtime before creating the IIS applications.

## Publish from Visual Studio

For each project:

1. Right-click the project.
2. Publish.
3. Select the `IIS` publish profile.
4. The profile publishes to:
   - API: `C:\inetpub\wwwroot\DynamicRuleEngineApi`
   - Web: `C:\inetpub\wwwroot\DynamicRuleEngineWeb`
5. In IIS Manager, convert each folder to an Application.

## Web -> API

Production Web configuration uses:

`http://localhost/DynamicRuleEngineApi/`

This is in `DynamicRuleEngine.Web/appsettings.Production.json`.

If your IIS site uses a different host name or HTTPS binding, change only `ApiBaseUrl` in that production settings file.

## API CORS

Production API allows:

`http://localhost/DynamicRuleEngineWeb`

If the IIS Web URL is different, update `Cors:AllowedOrigins` in `DynamicRuleEngine.Api/appsettings.Production.json`.

## Visual Studio

The Web and API projects intentionally do not contain Project/IIS Express launch profiles. IIS is the hosting process.

Do not press F5 expecting IIS Express. Publish the applications to IIS and browse the IIS URLs.

## web.config

Both projects contain an explicit `web.config` configured for `AspNetCoreModuleV2` and in-process hosting.
