using DynamicRuleEngine.Application.Interfaces.Services;
using DynamicRuleEngine.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace DynamicRuleEngine.Api.Controllers;

[ApiController]
[Route("api/rules")]
public sealed class RuleController : ControllerBase
{
    private readonly IRuleService _service;
    public RuleController(IRuleService service) => _service = service;

    [HttpGet("{workflowId:int}")]
    public async Task<IActionResult> Get(int workflowId) => Ok((await _service.GetAsync(workflowId)).Select(r => new
    {
        r.Id,
        r.WorkflowId,
        r.RuleName,
        r.RuleExpression,
        r.RuleType,
        r.ErrorMessage,
        r.Enabled,
        r.SortOrder
    }));

    [HttpPost]
    public async Task<IActionResult> Add([FromBody] RuleDefinition entity)
    {
        await _service.AddAsync(entity);
        return Ok(new { entity.Id });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] RuleDefinition entity)
    {
        entity.Id = id;
        await _service.UpdateAsync(entity);
        return Ok(new { entity.Id });
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        await _service.DeleteAsync(id);
        return NoContent();
    }
}
