using DynamicRuleEngine.Application.Interfaces.Repositories;
using DynamicRuleEngine.Application.Interfaces.Services;
using Microsoft.AspNetCore.Mvc;

namespace DynamicRuleEngine.Api.Controllers;

[ApiController]
[Route("api/workflows")]
public sealed class WorkflowController : ControllerBase
{
    private readonly IWorkflowRepository _repository;
    private readonly IWorkflowService _service;

    public WorkflowController(IWorkflowRepository repository, IWorkflowService service)
    {
        _repository = repository;
        _service = service;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll() => Ok((await _repository.GetAllAsync()).Select(x => new
    {
        x.Id,
        x.WorkflowCode,
        x.WorkflowName
    }));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var workflow = await _repository.GetWithConfigurationAsync(id);
        if (workflow is null) return NotFound();

        return Ok(new
        {
            workflow.Id,
            workflow.WorkflowCode,
            workflow.WorkflowName,
            Parameters = workflow.Parameters.Select(p => new
            {
                p.Id,
                p.WorkflowId,
                p.ParameterCode,
                p.DisplayName,
                p.Weight,
                p.WhyItMatters,
                p.HowToMeasure,
                p.IsActive,
                p.SortOrder,
                ScoreDefinitions = p.ScoreDefinitions.Select(s => new { s.Id, s.Score, s.Description }).ToList()
            }).ToList()
        });
    }

    [HttpGet("{id:int}/json")]
    public async Task<IActionResult> GetJson(int id) => Ok(await _service.GetWorkflowJsonAsync(id));

    [HttpPost("{id:int}/publish")]
    public async Task<IActionResult> Publish(int id)
    {
        await _service.SaveWorkflowJsonAsync(id);
        return Ok(new { message = "Workflow JSON published successfully." });
    }

    [HttpPost("{id:int}/evaluate")]
    public async Task<IActionResult> Evaluate(int id, [FromBody] Dictionary<string, object> input)
        => Ok(await _service.GetEvaluationAsync(id, input));
}
