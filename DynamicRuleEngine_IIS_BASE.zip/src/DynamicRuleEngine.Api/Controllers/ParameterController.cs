using DynamicRuleEngine.Application.Interfaces.Services;
using DynamicRuleEngine.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace DynamicRuleEngine.Api.Controllers;

[ApiController]
[Route("api/parameters")]
public sealed class ParameterController : ControllerBase
{
    private readonly IParameterService _service;
    public ParameterController(IParameterService service) => _service = service;

    [HttpGet("{workflowId:int}")]
    public async Task<IActionResult> Get(int workflowId) => Ok((await _service.GetAsync(workflowId)).Select(p => new
    {
        p.Id,
        p.WorkflowId,
        p.ParameterCode,
        p.DisplayName,
        p.Weight,
        p.WhyItMatters,
        p.HowToMeasure,
        p.IsActive,
        p.SortOrder,
        ScoreDefinitions = p.ScoreDefinitions.Select(s => new { s.Id, s.Score, s.Description }).ToList()
    }));

    [HttpPost]
    public async Task<IActionResult> Add([FromBody] ParameterDefinition entity)
    {
        await _service.AddAsync(entity);
        return Ok(new { entity.Id });
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] ParameterDefinition entity)
    {
        entity.Id = id;
        await _service.UpdateAsync(entity);
        return Ok(new { entity.Id });
    }
}
