using DynamicRuleEngine.Domain.Entities;
namespace DynamicRuleEngine.Application.Interfaces.Repositories;
public interface IRuleRepository
{
    Task<List<RuleDefinition>> GetByWorkflowAsync(int workflowId);
    Task<RuleDefinition?> GetAsync(int id);
    Task AddAsync(RuleDefinition entity);
    Task UpdateAsync(RuleDefinition entity);
    Task DeleteAsync(int id);
}
