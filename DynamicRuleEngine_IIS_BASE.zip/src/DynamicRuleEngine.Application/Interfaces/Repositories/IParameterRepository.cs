using DynamicRuleEngine.Domain.Entities;
namespace DynamicRuleEngine.Application.Interfaces.Repositories;
public interface IParameterRepository
{
    Task<List<ParameterDefinition>> GetByWorkflowAsync(int workflowId);
    Task<ParameterDefinition?> GetAsync(int id);
    Task AddAsync(ParameterDefinition entity);
    Task UpdateAsync(ParameterDefinition entity);
}
