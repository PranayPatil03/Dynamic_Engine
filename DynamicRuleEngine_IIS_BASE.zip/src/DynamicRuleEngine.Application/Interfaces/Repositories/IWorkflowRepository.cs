using DynamicRuleEngine.Domain.Entities;
namespace DynamicRuleEngine.Application.Interfaces.Repositories;
public interface IWorkflowRepository
{
    Task<List<Workflow>> GetAllAsync();
    Task<Workflow?> GetAsync(int id);
    Task<Workflow?> GetWithConfigurationAsync(int id);
    Task SaveJsonAsync(WorkflowJson entity);
}
