using DynamicRuleEngine.Domain.Entities;
namespace DynamicRuleEngine.Application.Interfaces.Services;
public interface IRuleService
{
    Task<List<RuleDefinition>> GetAsync(int workflowId);
    Task AddAsync(RuleDefinition entity);
    Task UpdateAsync(RuleDefinition entity);
    Task DeleteAsync(int id);
}
