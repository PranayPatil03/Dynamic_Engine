namespace DynamicRuleEngine.Application.Interfaces.Services;

public interface IWorkflowService
{
    Task<object> GetEvaluationAsync(int workflowId, Dictionary<string, object> input);
    Task SaveWorkflowJsonAsync(int workflowId);
    Task<object> GetWorkflowJsonAsync(int workflowId);
}
