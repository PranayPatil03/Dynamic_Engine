using DynamicRuleEngine.Domain.Entities;
namespace DynamicRuleEngine.Application.Interfaces.Services;
public interface IParameterService
{
    Task<List<ParameterDefinition>> GetAsync(int workflowId);
    Task AddAsync(ParameterDefinition entity);
    Task UpdateAsync(ParameterDefinition entity);
}
