using DynamicRuleEngine.Domain.Entities;
using Microsoft.EntityFrameworkCore;
namespace DynamicRuleEngine.Infrastructure.Data;
public class RuleEngineDbContext : DbContext
{
    public RuleEngineDbContext(DbContextOptions<RuleEngineDbContext> options):base(options){}
    public DbSet<Workflow> Workflows => Set<Workflow>();
    public DbSet<RuleDefinition> Rules => Set<RuleDefinition>();
    public DbSet<ParameterDefinition> Parameters => Set<ParameterDefinition>();
    public DbSet<ScoreDefinition> ScoreDefinitions => Set<ScoreDefinition>();
    public DbSet<WorkflowJson> WorkflowJson => Set<WorkflowJson>();
    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<Workflow>().ToTable("Workflows").HasKey(x=>x.Id);
        b.Entity<RuleDefinition>().ToTable("Rules").HasKey(x=>x.Id);
        b.Entity<ParameterDefinition>().ToTable("FrameworkParameters").HasKey(x=>x.Id);
        b.Entity<ScoreDefinition>().ToTable("ScoreDefinitions").HasKey(x=>x.Id);
        b.Entity<WorkflowJson>().ToTable("WorkflowJson").HasKey(x=>x.Id);
        b.Entity<Workflow>().HasMany(x=>x.Rules).WithOne(x=>x.Workflow).HasForeignKey(x=>x.WorkflowId);
        b.Entity<Workflow>().HasMany(x=>x.Parameters).WithOne(x=>x.Workflow).HasForeignKey(x=>x.WorkflowId);
        b.Entity<ParameterDefinition>().HasMany(x=>x.ScoreDefinitions).WithOne(x=>x.ParameterDefinition).HasForeignKey(x=>x.ParameterDefinitionId);
        b.Entity<Workflow>().HasOne(x=>x.WorkflowJson).WithOne(x=>x.Workflow).HasForeignKey<WorkflowJson>(x=>x.WorkflowId);
    }
}
