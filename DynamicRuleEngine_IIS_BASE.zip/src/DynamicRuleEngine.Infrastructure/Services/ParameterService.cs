using DynamicRuleEngine.Application.Interfaces.Repositories;
using DynamicRuleEngine.Application.Interfaces.Services;
using DynamicRuleEngine.Domain.Entities;

namespace DynamicRuleEngine.Infrastructure.Services;

public sealed class ParameterService : IParameterService
{
    private readonly IParameterRepository _repo;
    public ParameterService(IParameterRepository repo) => _repo = repo;

    public Task<List<ParameterDefinition>> GetAsync(int workflowId) => _repo.GetByWorkflowAsync(workflowId);

    public async Task AddAsync(ParameterDefinition entity)
    {
        if (entity.ScoreDefinitions.Count == 0)
        {
            entity.ScoreDefinitions = Enumerable.Range(1, 5)
                .Select(score => new ScoreDefinition
                {
                    Score = score,
                    Description = score switch
                    {
                        1 => "Very Low",
                        2 => "Low",
                        3 => "Moderate",
                        4 => "High",
                        _ => "Very High"
                    }
                }).ToList();
        }

        await _repo.AddAsync(entity);
    }

    public Task UpdateAsync(ParameterDefinition entity) => _repo.UpdateAsync(entity);
}
