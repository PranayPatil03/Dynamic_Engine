using System.Text.Json;
using DynamicRuleEngine.Application.Interfaces.Repositories;
using DynamicRuleEngine.Application.Interfaces.Services;
using DynamicRuleEngine.Domain.Entities;
using RulesEngine.Models;

namespace DynamicRuleEngine.Infrastructure.Services;

public sealed class WorkflowService : IWorkflowService
{
    private readonly IWorkflowRepository _workflows;

    public WorkflowService(IWorkflowRepository workflows) => _workflows = workflows;

    public async Task SaveWorkflowJsonAsync(int workflowId)
    {
        var workflow = await _workflows.GetWithConfigurationAsync(workflowId)
            ?? throw new InvalidOperationException("Workflow not found.");

        var ruleDocuments = new List<Dictionary<string, object?>>();
        foreach (var rule in workflow.Rules.Where(x => x.Enabled).OrderBy(x => x.SortOrder))
        {
            var item = new Dictionary<string, object?>
            {
                ["ruleName"] = rule.RuleName,
                ["enabled"] = rule.Enabled,
                ["ruleExpressionType"] = "LambdaExpression",
                ["expression"] = string.Equals(rule.RuleType, "Calculation", StringComparison.OrdinalIgnoreCase) ? "true" : rule.RuleExpression,
                ["errorMessage"] = rule.ErrorMessage
            };

            if (string.Equals(rule.RuleType, "Calculation", StringComparison.OrdinalIgnoreCase))
            {
                item["actions"] = new
                {
                    onSuccess = new
                    {
                        name = "OutputExpression",
                        context = new Dictionary<string, object>
                        {
                            ["expression"] = rule.RuleExpression
                        }
                    }
                };
            }

            ruleDocuments.Add(item);
        }

        var document = new
        {
            workflowName = workflow.WorkflowCode,
            ruleExpressionType = "LambdaExpression",
            rules = ruleDocuments
        };

        var json = JsonSerializer.Serialize(new[] { document }, new JsonSerializerOptions { WriteIndented = true });
        var version = (workflow.WorkflowJson?.Version ?? 0) + 1;

        await _workflows.SaveJsonAsync(new WorkflowJson
        {
            WorkflowId = workflowId,
            Version = version,
            JsonContent = json,
            GeneratedAtUtc = DateTime.UtcNow
        });
    }

    public async Task<object> GetWorkflowJsonAsync(int workflowId)
    {
        var workflow = await _workflows.GetWithConfigurationAsync(workflowId)
            ?? throw new InvalidOperationException("Workflow not found.");

        return new
        {
            workflowId = workflow.Id,
            workflowName = workflow.WorkflowName,
            version = workflow.WorkflowJson?.Version ?? 0,
            generatedAtUtc = workflow.WorkflowJson?.GeneratedAtUtc,
            json = workflow.WorkflowJson?.JsonContent ?? ""
        };
    }

    public async Task<object> GetEvaluationAsync(int workflowId, Dictionary<string, object> input)
    {
        var workflow = await _workflows.GetWithConfigurationAsync(workflowId)
            ?? throw new InvalidOperationException("Workflow not found.");

        if (workflow.WorkflowJson is null)
            throw new InvalidOperationException("Workflow JSON has not been generated yet. Open Rules and click Publish JSON.");

        var workflows = JsonSerializer.Deserialize<RulesEngine.Models.Workflow[]>(workflow.WorkflowJson.JsonContent)
            ?? throw new InvalidOperationException("Saved Workflow JSON is invalid.");

        var normalizedInput = input.ToDictionary(x => x.Key, x => NormalizeInputValue(x.Value));
        var engine = new RulesEngine.RulesEngine(workflows, null);
        var results = await engine.ExecuteAllRulesAsync(
            workflows[0].WorkflowName,
            new RuleParameter("input1", normalizedInput));

        var calculation = results.FirstOrDefault(x =>
            string.Equals(x.Rule.RuleName, "CalculateWeightedScore", StringComparison.OrdinalIgnoreCase));

        decimal? weightedScore = null;
        if (calculation?.ActionResult?.Output is not null &&
            decimal.TryParse(Convert.ToString(calculation.ActionResult.Output, System.Globalization.CultureInfo.InvariantCulture), out var parsed))
        {
            weightedScore = parsed;
        }

        return new
        {
            workflow = workflow.WorkflowName,
            version = workflow.WorkflowJson.Version,
            passed = results.Where(x => !string.Equals(x.Rule.RuleName, "CalculateWeightedScore", StringComparison.OrdinalIgnoreCase)).All(x => x.IsSuccess),
            weightedScore,
            results = results.Select(x => new
            {
                ruleName = x.Rule.RuleName,
                isSuccess = x.IsSuccess,
                exceptionMessage = x.ExceptionMessage,
                output = x.ActionResult?.Output
            })
        };
    }

    private static object NormalizeInputValue(object value)
    {
        if (value is not JsonElement json)
            return value;

        return json.ValueKind switch
        {
            JsonValueKind.Number when json.TryGetInt32(out var intValue) => intValue,
            JsonValueKind.Number when json.TryGetDecimal(out var decimalValue) => decimalValue,
            JsonValueKind.String => json.GetString() ?? string.Empty,
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            JsonValueKind.Null => string.Empty,
            _ => json.ToString()
        };
    }
}
