using DynamicRuleEngine.Application.Interfaces.Repositories;
using DynamicRuleEngine.Application.Interfaces.Services;
using DynamicRuleEngine.Domain.Entities;
namespace DynamicRuleEngine.Infrastructure.Services;
public class RuleService:IRuleService
{
    private readonly IRuleRepository _repo;
    private readonly IWorkflowService _workflowService;
    public RuleService(IRuleRepository repo,IWorkflowService workflowService){_repo=repo;_workflowService=workflowService;}
    public Task<List<RuleDefinition>> GetAsync(int id)=>_repo.GetByWorkflowAsync(id);
    public async Task AddAsync(RuleDefinition e){await _repo.AddAsync(e);await _workflowService.SaveWorkflowJsonAsync(e.WorkflowId);}
    public async Task UpdateAsync(RuleDefinition e){await _repo.UpdateAsync(e);await _workflowService.SaveWorkflowJsonAsync(e.WorkflowId);}
    public async Task DeleteAsync(int id){var e=await _repo.GetAsync(id);if(e!=null){await _repo.DeleteAsync(id);await _workflowService.SaveWorkflowJsonAsync(e.WorkflowId);}}
}
