using DynamicRuleEngine.Application.Interfaces.Repositories;
using DynamicRuleEngine.Domain.Entities;
using DynamicRuleEngine.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
namespace DynamicRuleEngine.Infrastructure.Repositories;
public class RuleRepository : IRuleRepository
{
    private readonly RuleEngineDbContext _db;
    public RuleRepository(RuleEngineDbContext db)=>_db=db;
    public Task<List<RuleDefinition>> GetByWorkflowAsync(int id)=>_db.Rules.Where(x=>x.WorkflowId==id).OrderBy(x=>x.SortOrder).ToListAsync();
    public Task<RuleDefinition?> GetAsync(int id)=>_db.Rules.FindAsync(id).AsTask();
    public async Task AddAsync(RuleDefinition e){_db.Rules.Add(e); await _db.SaveChangesAsync();}
    public async Task UpdateAsync(RuleDefinition e){_db.Rules.Update(e); await _db.SaveChangesAsync();}
    public async Task DeleteAsync(int id){var e=await _db.Rules.FindAsync(id); if(e!=null){_db.Rules.Remove(e); await _db.SaveChangesAsync();}}
}
