using DynamicRuleEngine.Application.Interfaces.Repositories;
using DynamicRuleEngine.Domain.Entities;
using DynamicRuleEngine.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
namespace DynamicRuleEngine.Infrastructure.Repositories;
public class WorkflowRepository : IWorkflowRepository
{
    private readonly RuleEngineDbContext _db;
    public WorkflowRepository(RuleEngineDbContext db)=>_db=db;
    public Task<List<Workflow>> GetAllAsync()=>_db.Workflows.Where(x=>x.IsActive).OrderBy(x=>x.Id).ToListAsync();
    public Task<Workflow?> GetAsync(int id)=>_db.Workflows.FindAsync(id).AsTask();
    public Task<Workflow?> GetWithConfigurationAsync(int id)=>_db.Workflows
        .Include(x=>x.Rules.OrderBy(r=>r.SortOrder))
        .Include(x=>x.Parameters.OrderBy(p=>p.SortOrder)).ThenInclude(p=>p.ScoreDefinitions.OrderBy(s=>s.Score))
        .Include(x=>x.WorkflowJson).FirstOrDefaultAsync(x=>x.Id==id);
    public async Task SaveJsonAsync(WorkflowJson entity)
    {
        var current=await _db.WorkflowJson.FirstOrDefaultAsync(x=>x.WorkflowId==entity.WorkflowId);
        if(current==null) _db.WorkflowJson.Add(entity);
        else { current.JsonContent=entity.JsonContent; current.Version=entity.Version; current.GeneratedAtUtc=entity.GeneratedAtUtc; }
        await _db.SaveChangesAsync();
    }
}
