using DynamicRuleEngine.Application.Interfaces.Repositories;
using DynamicRuleEngine.Domain.Entities;
using DynamicRuleEngine.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
namespace DynamicRuleEngine.Infrastructure.Repositories;
public class ParameterRepository : IParameterRepository
{
    private readonly RuleEngineDbContext _db;
    public ParameterRepository(RuleEngineDbContext db)=>_db=db;
    public Task<List<ParameterDefinition>> GetByWorkflowAsync(int id)=>_db.Parameters.Include(x=>x.ScoreDefinitions).Where(x=>x.WorkflowId==id).OrderBy(x=>x.SortOrder).ToListAsync();
    public Task<ParameterDefinition?> GetAsync(int id)=>_db.Parameters.Include(x=>x.ScoreDefinitions).FirstOrDefaultAsync(x=>x.Id==id);
    public async Task AddAsync(ParameterDefinition e){_db.Parameters.Add(e); await _db.SaveChangesAsync();}
    public async Task UpdateAsync(ParameterDefinition e){_db.Parameters.Update(e); await _db.SaveChangesAsync();}
}
