using System.Net.Http.Json;
using System.Text.Json;

namespace DynamicRuleEngine.Web.Services;

public sealed class RuleEngineApiClient
{
    private readonly HttpClient _http;

    public RuleEngineApiClient(HttpClient http)
    {
        _http = http;
    }

    public async Task<List<WorkflowDto>> GetWorkflowsAsync()
        => await GetAsync<List<WorkflowDto>>("api/workflows") ?? new List<WorkflowDto>();

    public Task<WorkflowDto?> GetWorkflowAsync(int id)
        => GetAsync<WorkflowDto>($"api/workflows/{id}");

    public async Task<List<ParameterDto>> GetParametersAsync(int workflowId)
        => await GetAsync<List<ParameterDto>>($"api/parameters/{workflowId}") ?? new List<ParameterDto>();

    public async Task SaveParameterAsync(ParameterDto model, bool update)
    {
        var response = update
            ? await _http.PutAsJsonAsync($"api/parameters/{model.Id}", model)
            : await _http.PostAsJsonAsync("api/parameters", model);
        await EnsureSuccessAsync(response);
    }

    public async Task<List<RuleDto>> GetRulesAsync(int workflowId)
        => await GetAsync<List<RuleDto>>($"api/rules/{workflowId}") ?? new List<RuleDto>();

    public async Task SaveRuleAsync(RuleDto model, bool update)
    {
        var response = update
            ? await _http.PutAsJsonAsync($"api/rules/{model.Id}", model)
            : await _http.PostAsJsonAsync("api/rules", model);
        await EnsureSuccessAsync(response);
    }

    public async Task DeleteRuleAsync(int id)
    {
        var response = await _http.DeleteAsync($"api/rules/{id}");
        await EnsureSuccessAsync(response);
    }

    public async Task PublishAsync(int workflowId)
    {
        var response = await _http.PostAsync($"api/workflows/{workflowId}/publish", null);
        await EnsureSuccessAsync(response);
    }

    public Task<WorkflowJsonDto?> GetJsonAsync(int workflowId)
        => GetAsync<WorkflowJsonDto>($"api/workflows/{workflowId}/json");

    public async Task<EvaluationResult?> EvaluateAsync(int workflowId, Dictionary<string, object> input)
    {
        var response = await _http.PostAsJsonAsync($"api/workflows/{workflowId}/evaluate", input);
        await EnsureSuccessAsync(response);
        return await response.Content.ReadFromJsonAsync<EvaluationResult>();
    }

    private async Task<T?> GetAsync<T>(string url)
    {
        var response = await _http.GetAsync(url);
        await EnsureSuccessAsync(response);
        return await response.Content.ReadFromJsonAsync<T>();
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response)
    {
        if (response.IsSuccessStatusCode)
        {
            return;
        }

        var body = await response.Content.ReadAsStringAsync();
        var message = string.IsNullOrWhiteSpace(body)
            ? response.ReasonPhrase ?? "Request failed."
            : body;

        throw new InvalidOperationException($"API error {(int)response.StatusCode}: {message}");
    }

    public sealed class WorkflowDto
    {
        public int Id { get; set; }
        public string WorkflowCode { get; set; } = string.Empty;
        public string WorkflowName { get; set; } = string.Empty;
        public List<ParameterDto> Parameters { get; set; } = new();
    }

    public sealed class ParameterDto
    {
        public int Id { get; set; }
        public int WorkflowId { get; set; }
        public string ParameterCode { get; set; } = string.Empty;
        public string DisplayName { get; set; } = string.Empty;
        public decimal Weight { get; set; }
        public string? WhyItMatters { get; set; }
        public string? HowToMeasure { get; set; }
        public bool IsActive { get; set; } = true;
        public int SortOrder { get; set; }
        public List<ScoreDto> ScoreDefinitions { get; set; } = new();
    }

    public sealed class ScoreDto
    {
        public int Id { get; set; }
        public int Score { get; set; }
        public string Description { get; set; } = string.Empty;
    }

    public sealed class RuleDto
    {
        public int Id { get; set; }
        public int WorkflowId { get; set; }
        public string RuleName { get; set; } = string.Empty;
        public string RuleExpression { get; set; } = string.Empty;
        public string RuleType { get; set; } = "Validation";
        public string? ErrorMessage { get; set; }
        public bool Enabled { get; set; } = true;
        public int SortOrder { get; set; }
    }

    public sealed class WorkflowJsonDto
    {
        public int WorkflowId { get; set; }
        public string WorkflowName { get; set; } = string.Empty;
        public int Version { get; set; }
        public DateTime? GeneratedAtUtc { get; set; }
        public string Json { get; set; } = string.Empty;
    }

    public sealed class EvaluationResult
    {
        public string Workflow { get; set; } = string.Empty;
        public int Version { get; set; }
        public bool Passed { get; set; }
        public decimal? WeightedScore { get; set; }
        public List<RuleResultDto> Results { get; set; } = new();
    }

    public sealed class RuleResultDto
    {
        public string RuleName { get; set; } = string.Empty;
        public bool IsSuccess { get; set; }
        public string? ExceptionMessage { get; set; }
        public JsonElement? Output { get; set; }
    }
}
