namespace DynamicRuleEngine.Domain.Entities;
public class WorkflowJson
{
    public int Id { get; set; }
    public int WorkflowId { get; set; }
    public int Version { get; set; }
    public string JsonContent { get; set; } = "";
    public DateTime GeneratedAtUtc { get; set; }
    public Workflow Workflow { get; set; } = null!;
}
