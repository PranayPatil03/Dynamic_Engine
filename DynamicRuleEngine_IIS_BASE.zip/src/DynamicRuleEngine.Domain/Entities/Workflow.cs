namespace DynamicRuleEngine.Domain.Entities;
public class Workflow
{
    public int Id { get; set; }
    public string WorkflowCode { get; set; } = "";
    public string WorkflowName { get; set; } = "";
    public bool IsActive { get; set; } = true;
    public List<RuleDefinition> Rules { get; set; } = new();
    public List<ParameterDefinition> Parameters { get; set; } = new();
    public WorkflowJson? WorkflowJson { get; set; }
}
