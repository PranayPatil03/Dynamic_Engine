namespace DynamicRuleEngine.Domain.Entities;
public class RuleDefinition
{
    public int Id { get; set; }
    public int WorkflowId { get; set; }
    public string RuleName { get; set; } = "";
    public string RuleExpression { get; set; } = "";
    public string RuleType { get; set; } = "Validation";
    public string? ErrorMessage { get; set; }
    public bool Enabled { get; set; } = true;
    public int SortOrder { get; set; }
    public Workflow Workflow { get; set; } = null!;
}
