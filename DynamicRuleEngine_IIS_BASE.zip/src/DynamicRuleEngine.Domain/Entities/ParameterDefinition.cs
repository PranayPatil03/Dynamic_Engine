namespace DynamicRuleEngine.Domain.Entities;
public class ParameterDefinition
{
    public int Id { get; set; }
    public int WorkflowId { get; set; }
    public string ParameterCode { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public decimal Weight { get; set; }
    public string? WhyItMatters { get; set; }
    public string? HowToMeasure { get; set; }
    public bool IsActive { get; set; } = true;
    public int SortOrder { get; set; }
    public Workflow Workflow { get; set; } = null!;
    public List<ScoreDefinition> ScoreDefinitions { get; set; } = new();
}
