namespace DynamicRuleEngine.Domain.Entities;
public class ScoreDefinition
{
    public int Id { get; set; }
    public int ParameterDefinitionId { get; set; }
    public int Score { get; set; }
    public string Description { get; set; } = "";
    public ParameterDefinition ParameterDefinition { get; set; } = null!;
}
