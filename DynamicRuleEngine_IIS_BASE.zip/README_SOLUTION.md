# Solution Structure

DynamicRuleEngine.sln contains:

- DynamicRuleEngine.Domain
- DynamicRuleEngine.Application
- DynamicRuleEngine.Infrastructure
- DynamicRuleEngine.Api
- DynamicRuleEngine.Web
- RulesEngine (actual Microsoft RulesEngine source)

IIS is the intended host for both executable web applications.
