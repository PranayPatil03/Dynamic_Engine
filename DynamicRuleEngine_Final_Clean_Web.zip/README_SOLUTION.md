# Dynamic Rule Engine - Final Clean Architecture Demo

## Included
- .NET 10 Clean Architecture: Domain, Application, Infrastructure, API, Web
- Microsoft RulesEngine source is included under `Libraries/RulesEngine` (not an empty wrapper and not the RulesEngine NuGet package)
- EF Core + SQL Server; no stored procedures and no EF migrations
- Repository + Service pattern
- MudBlazor pages:
  - Framework Evaluation
  - Parameter Configuration
  - Rule Configuration
  - Persisted Workflow JSON
- Business, Operational and Financial workflows

## Important behavior
1. Parameter add/update changes only database parameter data. It does **not** regenerate WorkflowJson or change its version.
2. Rule add/update/delete regenerates WorkflowJson and increments its version.
3. Runtime evaluation reads the latest persisted WorkflowJson and passes it to the included Microsoft RulesEngine source.
4. Validation and calculation expressions are persisted in the Rules table and copied into WorkflowJson. C# does not contain business-specific score formulas.
5. Calculation rules use RulesEngine `OutputExpression` actions from the saved JSON.

## Run
1. Open `Database/01_CreateDatabase.sql` in SSMS and execute it.
2. Open `DynamicRuleEngine.sln` in Visual Studio 2022 with the .NET 10 SDK.
3. Set `DynamicRuleEngine.Api` and `DynamicRuleEngine.Web` as startup projects.
4. API: `http://localhost:5101/swagger`
5. Web: `http://localhost:5200`

If IIS is used, publish API and Web separately and change `ApiBaseUrl` in Web `appsettings.json` to the IIS API URL. Update API CORS origins to the IIS Web URL.

## Library source
`Libraries/RulesEngine` contains the actual source extracted from the provided Microsoft RulesEngine repository. The application references this project directly from Infrastructure.

## Build verification
The environment used to create this archive does not have the .NET SDK installed, so a real `dotnet build`/Visual Studio build could not be executed here. The project files and source references were checked statically; build in Visual Studio before deployment.
