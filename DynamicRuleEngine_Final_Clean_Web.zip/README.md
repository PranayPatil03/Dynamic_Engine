# Dynamic Rule Engine - Final Clean Solution

.NET 10 + Blazor Web App + MudBlazor + Clean Architecture + SQL Server + Microsoft RulesEngine source.

## Projects
- DynamicRuleEngine.Domain
- DynamicRuleEngine.Application
- DynamicRuleEngine.Infrastructure
- DynamicRuleEngine.Api
- DynamicRuleEngine.Web
- Libraries/RulesEngine (Microsoft RulesEngine source)

## Web pages
- `/` Framework Evaluation
- `/parameters` Parameter Configuration
- `/rules` Rule Configuration
- `/workflow-json` Persisted Workflow JSON

## Run
1. Execute `Database/01_CreateDatabase.sql` in SQL Server.
2. Check the API connection string in `src/DynamicRuleEngine.Api/appsettings.json`.
3. Start `DynamicRuleEngine.Api` on its configured IIS/HTTP binding.
4. Set `ApiBaseUrl` in `src/DynamicRuleEngine.Web/appsettings.json` to the API URL.
5. Start `DynamicRuleEngine.Web`.

Parameter changes do not regenerate WorkflowJson. Rule changes regenerate WorkflowJson and increment its version.
